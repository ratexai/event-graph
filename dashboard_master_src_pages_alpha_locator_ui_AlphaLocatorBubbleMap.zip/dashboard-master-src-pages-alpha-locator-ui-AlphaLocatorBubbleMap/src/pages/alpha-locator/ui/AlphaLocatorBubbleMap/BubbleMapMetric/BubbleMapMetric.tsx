import { FC } from 'react'

import arrowIcon from './arrow.svg'
import xIcon from '#assets/icons/twitter-x-circle.svg'
import { cx } from '#SHARED/lib'

import s from './bubbleMapMetric.module.scss'

export const BubbleMapMetric: FC = () => {
  return (
    <div className={s.metrics}>
      <div className={s.socialLabel}>
        <img alt="Social icon" className={s.icon} src={xIcon} />
      </div>
      <div className={s.dashboard}>
        <div className={s.labels}>
          <div className={s.label}>
            <div className={cx(s.indicator, s.positive)} />
            <p className={s.value}>3.6K</p>
            <img alt="Arrow icon" className={s.icon} src={arrowIcon} />
            <span className={s.percentValue}>23.47%</span>
          </div>
          <div className={s.label}>
            <div className={cx(s.indicator, s.negative)} />
            <p>3.6K</p>
            <img alt="Arrow icon" className={s.icon} src={arrowIcon} />
            <span className={s.percentValue}>23.47%</span>
          </div>
        </div>
        <div className={s.progressLine}>
          <div className={s.positive} />
          <div className={s.negative} />
        </div>
      </div>
    </div>
  )
}
