import { FC } from 'react'

import arrowBullish from '#assets/icons/arrow-zipper.svg'
import { CoinRatingEnum } from '#ENTITIES/CoinRating/types/CoinRatingEnum'
import { ScoreAndRating } from '#FSD_WIDGETS/ScoreAndRating'
import { cx } from '#SHARED/lib'
import { Size } from '#SHARED/types/size'
import { Tag } from '#SHARED/ui'

import { TBubbleTooltip } from '../../../types/tooltip'

import s from './bubbleMapTooltip.module.scss'

const totalScoreData = [
  {
    gold: true,
    label: 'Earned RXAI Points',
    value: '+8,154 RXAI',
  },
  {
    label: 'Last 7D',
    value: '+1,230 RXAI',
  },
  {
    label: 'Last 30D',
    value: '+6,924 RXAI',
  },
]

const metricsData = [
  {
    change: '+14.99%',
    label: 'Mindshare%, 7D',
    value: '3.23%',
  },
  {
    bullish: true,
    label: 'Market Mood, 7D',
    value: '+0.72',
  },
  {
    change: '+12.85%',
    label: 'Smart Followers, 7D',
    value: '95.3K',
  },
]

export const BubbleMapTooltip: FC<TBubbleTooltip> = ({ data }) => {
  return (
    <div className={s.tooltipContainer}>
      <div className={s.user}>
        <div className={s.content}>
          <img alt={data.name} className={s.avatar} src={data.icon} />
          <div className={s.info}>
            <p className={s.name}>
              {data.name} <span className={s.nickName}>@farokh</span>
            </p>
            <div className={s.tags}>
              <Tag color="green">KOL</Tag>
              <Tag color="green">Media</Tag>
            </div>
          </div>
        </div>
        <ScoreAndRating rating={CoinRatingEnum.aaa} score={5} size={Size.sm} type="social" />
      </div>
      <div className={s.totalScore}>
        {totalScoreData.map((item) => (
          <div className={s.totalScoreItem} key={item.label}>
            <p className={s.label}>{item.label}</p>
            <span className={cx(s.value, item.gold && s.gold)}>{item.value}</span>
          </div>
        ))}
      </div>
      <div className={s.metrics}>
        {metricsData.map((item) => (
          <div className={s.metricsItem} key={item.label}>
            <p className={s.label}>{item.label}</p>
            <div className={s.content}>
              <span className={s.value}>{item.value}</span>
              {item.bullish && (
                <div className={s.bullish}>
                  <img alt="Arrow icon" className={s.arrow} src={arrowBullish} />
                  <span className={s.bullishLabel}>Bullish</span>
                </div>
              )}
              {item.change && <span className={s.change}>{item.change}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
