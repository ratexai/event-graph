import { FC, useCallback } from 'react'

import { BubbleConfig, BubbleData, BubbleNode, D3GSelection } from '#SHARED/types'
import { BubbleChart } from '#SHARED/ui'

type Props = {
  data: BubbleData[]
  height: number
  onNodeHover?: (node: BubbleNode, event: Pick<MouseEvent, 'clientX' | 'clientY'>) => void
  onNodeHoverEnd?: () => void
  width: number
}

const holdersConfig: BubbleConfig = {
  gapDivisor: 15,
  gradient: [
    { offset: '0%', opacity: 0.2 },
    { offset: '70%', opacity: 0.4 },
    { offset: '100%', opacity: 0.8 },
  ],
}

export const AlphaLocatorBubbleChart: FC<Props> = (props) => {
  const renderContent = useCallback((div: D3GSelection) => {
    div
      .append('img')
      .attr('src', (item: BubbleNode) => item.icon)
      .style('width', (item: BubbleNode) => `${item.r / 1.8}px`)
      .style('height', (item: BubbleNode) => `${item.r / 1.8}px`)
      .style('border-radius', '50%')
      .style('pointer-events', 'none')

    const infoContainer = div
      .append('div')
      .style('display', 'flex')
      .style('flex-direction', 'column')
      .style('align-items', 'center')
      .style('gap', (item: BubbleNode) => `${Math.max(1, item.r / 20)}px`)
      .style('pointer-events', 'none')

    infoContainer
      .append('div')
      .style('font-size', (item: BubbleNode) => `${Math.min(item.r / 4, 16)}px`)
      .style('font-weight', 'medium')
      .style('color', 'white')
      .style('text-align', 'center')
      .style('pointer-events', 'none')
      .text((item: BubbleNode) => item.name)
  }, [])

  return <BubbleChart {...props} config={holdersConfig} renderContent={renderContent} />
}
