import { FC, useMemo } from 'react'

import { AlphaLocatorBubbleChart } from './AlphaLocatorBubbleChart'
import { BubbleMapFilter } from './BubbleMapFilter/BubbleMapFilter'
import { BubbleMapMetric } from './BubbleMapMetric/BubbleMapMetric'
import { BubbleMapTooltip } from './BubbleMapTooltip/BubbleMapTooltip'
import { useClient } from '#SHARED/hooks'
import { useBubbleMapTooltip } from '#SHARED/hooks/useBubbleMapTooltip'
import { useContainerSize } from '#SHARED/hooks/useContainerSize'
import { BubbleMapTooltipWrapper, ContainerWidget, NoDataBlock, Skeleton } from '#SHARED/ui'
import { useMediaQuery } from 'react-responsive'

import type { BubbleData, SizeContainer } from '#SHARED/types'

import { generateBubbleData } from '../../utils/generateBubblesData'

import s from './alphaLocatorBubbleMap.module.scss'
import mediaQueries from '@styles/_media-queries.vars.module.scss'

const DEFAULT_CONTAINER_SIZE: SizeContainer = { height: 550, width: 800 }

export const AlphaLocatorBubbleMap: FC = () => {
  const isClient = useClient()
  const { containerRef, size } = useContainerSize(DEFAULT_CONTAINER_SIZE)
  const { computeX, handleNodeHover, handleNodeHoverEnd, tooltipData, tooltipRef, tooltipVisible } =
    useBubbleMapTooltip(containerRef)

  const isTabletXl = useMediaQuery({ query: `(max-width: ${mediaQueries.tabletXl})` })
  const isLaptopM = useMediaQuery({ query: `(max-width: ${mediaQueries.laptopM})` })

  const bubbleLimit = isTabletXl ? 26 : isLaptopM ? 32 : 40

  const data: BubbleData[] = useMemo(() => {
    return generateBubbleData(bubbleLimit)
  }, [bubbleLimit])

  const hasData = data.length > 0

  return (
    <ContainerWidget className={s.alphaLocatorBubbleMap}>
      <div className={s.content}>
        <div className={s.header}>
          <BubbleMapMetric />
          <BubbleMapFilter />
        </div>
        <div className={s.container} ref={containerRef}>
          {!isClient ? (
            <Skeleton fill h={400} loading w="100%" />
          ) : !hasData ? (
            <NoDataBlock />
          ) : (
            <AlphaLocatorBubbleChart
              data={data}
              height={size.height}
              onNodeHover={handleNodeHover}
              onNodeHoverEnd={handleNodeHoverEnd}
              width={size.width}
            />
          )}
        </div>
      </div>

      <BubbleMapTooltipWrapper
        computeX={computeX}
        ref={tooltipRef}
        tooltipData={tooltipData}
        tooltipVisible={tooltipVisible}
      >
        <BubbleMapTooltip
          data={{
            icon: tooltipData?.node.icon ?? 'N/A',
            name: tooltipData?.node.name ?? 'N/A',
          }}
        />
      </BubbleMapTooltipWrapper>
    </ContainerWidget>
  )
}
