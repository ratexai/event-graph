import { FC, useState } from 'react'

import { cx } from '#SHARED/lib'
import { Size } from '#SHARED/types'
import { Button } from '#SHARED/ui'
import { useTranslation } from 'react-i18next'

import s from './bubbleMapFilter.module.scss'

enum Filter {
  all = 'all',
  projects = 'projects',
  kols = 'kols',
  media = 'media',
  vcs = 'vcs',
  aiAgents = 'aiAgents',
}

export const BubbleMapFilter: FC = () => {
  const { t } = useTranslation()
  const [activeFilter, setActiveFilter] = useState<Filter>(Filter.all)

  const handleFilterClick = (filter: typeof activeFilter) => {
    setActiveFilter(filter)
  }

  return (
    <div className={s.filterWrapper}>
      <div className={s.filter}>
        <Button
          className={cx(s.btn, activeFilter === Filter.all && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.all)}
          size={Size.sm}
        >
          {t('all')}
        </Button>
        <Button
          className={cx(s.btn, activeFilter === Filter.projects && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.projects)}
          size={Size.sm}
        >
          {t('projects')}
        </Button>
        <Button
          className={cx(s.btn, activeFilter === Filter.kols && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.kols)}
          size={Size.sm}
        >
          {t('kols')}
        </Button>
        <Button
          className={cx(s.btn, activeFilter === Filter.media && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.media)}
          size={Size.sm}
        >
          {t('media')}
        </Button>
        <Button
          className={cx(s.btn, activeFilter === Filter.vcs && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.vcs)}
          size={Size.sm}
        >
          {t('vcs')}
        </Button>
        <Button
          className={cx(s.btn, activeFilter === Filter.aiAgents && s.active)}
          color="filter"
          onClick={() => handleFilterClick(Filter.aiAgents)}
          size={Size.sm}
        >
          {t('aiAgents')}
        </Button>
      </div>
    </div>
  )
}
